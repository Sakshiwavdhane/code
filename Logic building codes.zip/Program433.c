#include<stdio.h>

void Display()
{
    int iCnt = 0;

    iCnt = 1;
    while(iCnt <= 4)
    {
        printf("Jay Ganesh...\n");
        iCnt++;
    }
}

int main()
{
    Display();

    return 0;
}