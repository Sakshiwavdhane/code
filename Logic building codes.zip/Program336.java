import java.util.*;
import java.io.*;

class Program336
{
    public static void main(String arg[]) throws Exception
    {
        Scanner sobj = new Scanner(System.in);

        String str = "Hello World";

        str = str.replaceAll("l","_");

        System.out.println(str);
    }
}