        #include<stdio.h>

        // Function Defination
        void Display()      // Dukan
        {
            printf("Inside Display Function...\n");
        }

        int main()      // Ghar
        {
            printf("Inside main Function...\n");

            Display();      // Function Call

            return 0;
        }