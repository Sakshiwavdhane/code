


            #include<stdio.h>

            int main()
            {
                printf("Good Evening...\n");

                return 0;
            }

// Step 1 : Open the command prompt
// MicrosftKey + R and enter CMD
// Search CMD in start option

// Step 2 : Open the folder which contains your .c files

// Step 2 : Press Alt+d which selects the search bar then write CMD there which will 
// open the command prompt from the specific path

// Step 4 : Compile the code
// gcc  21August.c  -o  Myexe

// Step 5 : Execute the code
// ./Myexe          Myexe       .\Myexe




#define  DOZEN   12
#define  SHEKADA 100
