package Marvellous.Infosystems;

public class Arithematic
{
    public int Substraction(int A, int B)
    {
        return A-B;
    }
}

// javac -d . Arithematic.java
